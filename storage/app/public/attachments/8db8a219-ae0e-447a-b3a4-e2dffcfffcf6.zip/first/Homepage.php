<?php
ini_set('display_errors', 0);
$username=$password="";
session_start();


$link = mysqli_connect("localhost", "root", "", "proud");
$loginsuccess=0;




?>

<!DOCTYPE html>
<html>

<head>
<title>Home Page</title>
<h1 class="head">PRODIGY</h1>
<link rel="stylesheet" type="text/css" href="style.css">

</head>

<body background="main4.jpg">

<?php if($loginsuccess==5){
	 print '<font color="#FF0000">No match in our records, try again <br></font>';}
	else if($loginsuccess==1){

	}
		 echo "user: ". $_SESSION['username'];

	?>

<div class="news">
<h2>NEWS</h2>
under construction<br>

<?php
if(isset($_SESSION['username'])){
	echo "user : ".$_SESSION['username']."\n";
}
else{
	echo "user : default :(non-member)";
}
?>

</div>


<div class="logout">

<button class="but_logout"><a href="logout.php">LOGOUT</a></button>

</div>


<div class="menu">
<table cellspacing="10" cellpadding="10">

<tr></tr>
	<td bordercolor="#C71C1F"><a href="Homepage.php">HOME</a></td>
<tr></tr>
    <td><a href="about.html">ABOUT</a></td>
<tr></tr>
	<td><a href="contact.html">CONTACT</a></td>
<tr></tr>
    <td><a href="sign_up_page.php">REGISTER</a></td>
    <tr></tr>
    <td><a href="profile.php">PROFILE</a></td>
    

</table>
</div>

<div class="cata">
        	<button class="but"><a href="robo.html">Robotic-Competition</a></button><br>
            <button class="but"><a href="code.html">programming-contest</a></button><br>
            <button class="but"><a href="apps.html">Apps-Contest</a></button><br>
            <button class="but"><a href="pro.html">Project-Showcasing</a></button><br>
            <button class="but"><a href="join.html">Join a contest</a></button><br>
         	
</div>


</div>
</body>

</html>