<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "proud";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}



include_once "connect_to_mysql.php";


echo "<br /><h2>You are successfully connected to your database.</h2><br /><br />
Otherwise you would see an include warning, or a mysql connection error.<br /><br />
Happy coding!
";
?>