<?php
ini_set('display_errors', 0);
$link = mysqli_connect("localhost", "root", "", "proud");
$loginsuccess=0;



session_start();
if(!isset($_SESSION['username'])) {
	$_SESSION['username']="default (non-member)";
	}

if (isset($_COOKIE["username"])){
	$username=$_COOKIE["username"];
	$password=$_COOKIE["password"];

}

$username=$password="";

if(isset($_POST['username'])) {

$username = stripslashes($_POST['username']);
$username = strip_tags($username);
$username = mysqli_real_escape_string($link,$username);
$password = preg_replace("[^A-Za-z0-9]", "", $_POST['password']); // filter everything but numbers and letters
//$password = md5($password);

$sql = mysqli_query($link,"SELECT * FROM signup WHERE username='$username' AND password='$password' ");
$login_check = mysqli_num_rows($sql);
//echo $login_check ;




if($login_check > 0){
		$loginsuccess=1;
		
		
    while($row = mysqli_fetch_array($sql)){ 
        $_SESSION['id']       = $row["id"];
        $_SESSION['username'] = $row["username"];
		$_SESSION['password'] = $row["password"];
		$_SESSION['email'] = $row["email"];
		$_SESSION['fullname'] = $row["fullname"];
		$_SESSION['mobile'] = $row["mobile"];
		$_SESSION['hscYear'] = $row["hscYear"];
		$_SESSION['bd'] = $row["bd"];
		$_SESSION['inst'] = $row["inst"];
		$_SESSION['time'] = $row["time"];
	
		
		if($_POST['remember']) {
			setcookie("username", $row["username"], time()+60*60*24);
			setcookie("password", $row["password"], time()+60*60*24);
		}
		else{
			$_COOKIE["username"]="";
			$_COOKIE["password"]="";
		}
        $loginsuccess=1;
		header("location:Homepage.php");
    } // close while
} else{
	$loginsuccess=5;
}

}// close if post

?>

<!DOCTYPE html>
<html>

<head>
<title>Home Page</title>
<h1 class="head">PRODIGY</h1>
<link rel="stylesheet" type="text/css" href="style.css">

</head>

<body background="main4.jpg">




<div class="up">

<?php
if($loginsuccess==5){
	 print '<font color="#FF0000">No match in our records, try again <br></font>';
}
else if($loginsuccess==1){
	 echo "welcome"." ".$_SESSION['username']."!";
	 echo "session user :". $_SESSION['username'];

}

?>

<?php
if(isset($_SESSION['username'])){
	echo "user : ".$_SESSION['username']."\n";
}
else{
	echo "user : default :(non-member)";
}
?>
<form action="home.php" method="post" enctype="multipart/form-data">
<h2>Login Here</h2>
User :<input type="text" name="username" value=""><br>
Pass :<input type="password" name="password"><br>
<label >
		<input type="checkbox" name="remember" value="1" id="on"> Remember me
		</label><br>
<input text-align="center" type="submit" name="submit" value="LOGIN"><br>

<?php if(isset($_COOKIE["username"])){
	echo "cookie user : ".$_COOKIE["username"]."\n";
	echo "cookie pass : ".$_COOKIE["password"]."\n";
}
?>

</form>
</div>

<div class="menu">
<table cellspacing="10" cellpadding="10">

<tr></tr>
	<td bordercolor="#C71C1F"><a href="Homepage.php">HOME</a></td>


<tr></tr>
    <td><a href="about.html">ABOUT</a></td>
<tr></tr>
	<td><a href="contact.html">CONTACT</a></td>
<tr></tr>
    <td><a href="sign_up_page.php">REGISTER</a></td>

</table>
</div>

<div class="news">
<h2>NEWS</h2>
under construction<br>





</div>

<div class="des"><b>
This is a public page for all the university going students of Bangladesh who are interested in different types of online or offline competitions.  There are many types of competitions like <i>programming contest, idea showcasing, line follower or maze solver robotic competitions</i> and so on. You can get all the latest updates of all these competitions and most importantly the upcoming events. We will try our best to provide all the informations needed. Thank You</b>
</div>
</body>

</html>