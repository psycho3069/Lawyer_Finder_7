<?php

session_start();

session_destroy(); 

header( "location:home.php" );



if($_SESSION['id'] ){ 
$msg = "You are now logged out";
} else{
	$_SESSION['id']="";
	if($_SESSION['id']==""){
		$msg = "<h2>login first</h2>";

		}
} 
?> 
<html>
<body>


</body>
</html>