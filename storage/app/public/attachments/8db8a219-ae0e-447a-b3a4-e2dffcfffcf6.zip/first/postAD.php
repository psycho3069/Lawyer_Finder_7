<!DOCTYPE html>

<html>
<head>
<title></title>
<link type="text/css" rel="stylesheet" href="postAD.css">

</head>

	<body>
    	<form>
        
        <p> <label class="field" for="name">Add an image: </label><input type="file" name="image1"  value="<?php echo $image1 ?>"></p>
        <p> <label class="field" for="name">Job Title: </label><input type="text"  placeholder="title" name="title"  value="<?php echo $title ?>"></p>
         <p> <label class="field" for="name">Description: </label><textarea rows="4" cols="5" placeholder="" name="des"  value="<?php echo $des ?>"></p>
        
        <br><br>
        <div class="">
        	Contact details :<br>
            <p> <label class="field" for="name"> Username: </label><input type="text"  placeholder="Your name" name="username"  value="<?php echo $username ?>"></p>
            <p> <label class="field" for="name"> Mobile       :</label><input type="text" placeholder="Contact no"  name="mobile" value="<?php echo $mobile ?>" ></p>
<p> <label class="field" for="name"> E-Mail         :</label><input type="text" placeholder="something@domain.com" name="email"  value="<?php echo $email ?>"></p>
        </div>
        </form>
    </body>




</html>