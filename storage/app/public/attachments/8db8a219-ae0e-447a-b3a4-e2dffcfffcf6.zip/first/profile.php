<!doctype html>
<html>
<head>

<h1 class="head">PRODIGY</h1>
<link rel="stylesheet" type="text/css" href="style.css">

<meta charset="utf-8">
<title>My Profile</title>
</head>

<body>

<div class="logout">

<button class="but_logout"><a href="logout.php">LOGOUT</a></button>

</div>

<div class="menu">
<table cellspacing="10" cellpadding="10">

<tr></tr>
	<td bordercolor="#C71C1F"><a href="Homepage.php">HOME</a></td>
<tr></tr>
    <td><a href="about.html">ABOUT</a></td>
<tr></tr>
	<td><a href="contact.html">CONTACT</a></td>
<tr></tr>
    <td><a href="sign_up_page.php">REGISTER</a></td>
    <tr></tr>
    <td><a href="profile.php">PROFILE</a></td>
    

</table>
</div>



<div class="profile_det">

<h1>Account Details :</h1>


<?php

session_start();

if(isset($_SESSION['username'])){
	echo "username : ".$_SESSION['username']."<br>";
	echo "email : ".$_SESSION['email']."<br>";
	echo "fullname : ".$_SESSION['fullname']."<br>";
	echo "bd : ".$_SESSION['bd']."<br>";
	echo "hscYear : ".$_SESSION['hscYear']."<br>";
	echo "Institution : ".$_SESSION['inst']."<br>";
	echo "mobile : ".$_SESSION['mobile']."<br>";
	echo "ID : ".$_SESSION['id'];
}
else{
	echo "user : default :(non-member)";
}

?>
<br>


<button class="but_profile"><a href="update_profile.php">Update Profile</a></button>

</div>



</body>
</html>