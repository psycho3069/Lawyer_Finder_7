<?php
$link = mysqli_connect("localhost", "root", "", "proud");
session_start();


$name2=$errorMsg = $username = $email = $password = $fullname = $mobile = $hscYear = $bd = $inst =  "";
$success=0;
$msg=0;
if (isset($_POST['username'])){
	$username = preg_replace("[^A-Za-z0-9]", "", $_POST['username']); // filter everything but numbers and letters   
    $email = test_input($_POST["email"]);
	$password = preg_replace("[^A-Za-z0-9]", "", $_POST['password']); // filter everything but numbers and letters
	$fullname = preg_replace("[^A-Za-z ]", "", $_POST['fullname']);
	$mobile = preg_replace("[^0-9]", "", $_POST['mobile']);
	$hscYear = $_POST['hscYear'];
	$bd = $_POST['bd'];
	$inst = $_POST['inst'];

	if((!$username)|| (!$email) || (!$password) || (!$fullname) || (!$mobile) || (!$hscYear) || (!$bd) || (!$inst) ){
		$errorMsg = "You must submit ";
		if(!$username){
			$c=1;
			$errorMsg .= "a unique <b><i>Username</i></b> to continue";
		}
		else if(!$email){
			$c=2; 
	       $errorMsg .= "<b><i>Email</i></b> Address to continue"; 
	   }
	   else if(!$password){
		   $c=3;
	       $errorMsg .= "<b><i>Password</i></b> to continue"; 
	   }
	   else if(!$fullname){
		   $c=4; 
	       $errorMsg .= "<b><i>Full Name</i></b> to continue"; 
	   }
	   else if(!$mobile){
		   $c=5; 
	       $errorMsg .= "<b><i>Mobile number</i></b> to continue"; 
	   }
	   else if(!$hscYear){
		   $c=6;
	       $errorMsg .= "<b><i>HSC passing year</i></b> to continue"; 
	   }
	   else if(!$bd){
		   $c=7;
	       $errorMsg .= "<b><i>Birthdate</i></b> to continue"; 
	   }
	   else if(!$inst){
		   $c=8; 
	       $errorMsg .= "Your present <b><i>Institution</i></b> to continue"; 
	   }
	   
	   
	}else if (!preg_match("/^[a-zA-Z0-9 ]*$/",$username))
       {
       $errorMsg = "Only letters, digits and white space allowed in username";
       }
		else if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$email))
        {
            $errorMsg = "Please input the valid Email format";
        }
		else if (!preg_match("/^[a-zA-Z0-9 ]*$/",$password))
       {
            $errorMsg = "Only letters, digits and white space allowed in Password";
       }
	   else if (!preg_match("/^[a-zA-Z ]*$/",$fullname))
       {
            $errorMsg = "Only letters and white space are allowed in Name";
       }
	   else if (!preg_match("/^[0-9]*$/",$mobile))
       {
            $errorMsg = "Only letters, digits and white space allowed in mobile number";
       }
 
	   else {
	// Database duplicate Fields Check
	$sql_username_check = mysqli_query($link,"SELECT id FROM signup WHERE username='$username' LIMIT 1");
	$sql_email_check = mysqli_query($link,"SELECT id FROM signup WHERE email='$email' LIMIT 1");
	$username_check = mysqli_num_rows($sql_username_check);
	$email_check = mysqli_num_rows($sql_email_check); 
	
	

	
	
	if ($username_check > 0){ 
		$errorMsg = "<u>ERROR:</u><br />Username already exits. Please try another.";
	} else if ($email_check > 0){ 
		$errorMsg = "<u>ERROR:</u><br />Email address is already used. Please try another.";
	} else {
		// Add MD5 Hash to the password variable
       $hashedPass = md5($password); 
	   
	   
   
	   
	   
		// Add user info into the database table, claim your fields then values 
		$sql = mysqli_query($link,"INSERT INTO signup (username ,email, password, fullname, mobile, hscYear, bd, inst, time) 
		VALUES('$username','$email','$password','$fullname','$mobile','$hscYear','$bd','$inst','now()')");
		$success = 1;
		


		
	} // Close else after database duplicate field value checks
  } // Close else after missing vars check
} //Close if $_POST


function test_input($data)
{
     $data = trim($data);
     $data = stripslashes($data);
     $data = htmlspecialchars($data);
     return $data;
}
?>
<!DOCTYPE html>
<html>

<head>

<link rel="stylesheet" type="text/css" href="sign_up_page.css">



</head>

<body>

<div  > 
    <form action="sign_up_page.php" method="post" enctype="multipart/form-data"> 
  <fieldset>


<legend class="login_up"><p><h1>Register Here</h1></p></legend>

<p1 style="color:red;"><?php echo "$errorMsg"; ?></p1>

<?php if($success==1){
	$name2=$fullname;
	$errorMsg = $username = $email = $password = $fullname = $mobile = $hscYear = $bd = $inst =  "";
	 echo '<p style="color: green; text-align: left">
	 <br>Hello!!</p>'." ".$name2." ".'<p style="color:blue; ">
	 <br> Thank you for your kind info !!
      </p>';
	
	$success=0;
	}
?>

<p> <label class="field" for="name"> Username: </label><input type="text"  placeholder="Your name" name="username"  value="<?php echo $username;  ?>"></p>
<p> <label class="field" for="name"> E-Mail         :</label><input type="text" placeholder="something@domain.com" name="email"  value="<?php echo $email ?>"></p>
<p> <label class="field" for="name"> Password       :</label><input type="password" placeholder="Letters, numbers and spaces"  name="password" ? ></p>
<p> <label class="field" for="name"> Full Name       :</label><input type="text" placeholder="Letters and spaces"  name="fullname" value="<?php echo $fullname ?>" ></p>
<p> <label class="field" for="name"> Mobile       :</label><input type="text" placeholder="Contact no"  name="mobile" value="<?php echo $mobile ?>" ></p>
<p> <label class="field" for="name"> HSC Year       :</label><select name="hscYear" value="<?php echo $hscYear ?>"><br>
<option>-select year-</option>
<option>2010</option>
<option>2011</option>
<option>2012</option>
<option>2013</option>
<option>2014</option>
<option>2015</option>
<option>2016</option><br></select></p>
<p> <label class="field" for="name"> Birthday       :</label><input type="date"   name="bd" value="<?php echo $bd ?>" ></p>
<p> <label class="field" for="name"> Institution       :</label><select name="inst" value="<?php echo $inst ?>"><br>
<option>-select institution-</option>
<option>BUET</option>
<option>KUET</option>
<option>RUET</option>
<option>CUET</option>
<option>IUT</option>
<option>AUST</option>
<option>SUST</option>
<option>NSU</option>
<option>DUET</option>
<option>AUBAT</option>
<option>BRAC</option>
<option>DIU</option>
<option>AIUB</option>
<option>-other-</option><br></select></p>





<input type="submit" class="button" name="submit" value="Submit Form">


 </fieldset>
</form></div> 

</body>

</html>