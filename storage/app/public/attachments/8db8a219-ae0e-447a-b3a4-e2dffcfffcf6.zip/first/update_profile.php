<?php

session_start();
$link = mysqli_connect("localhost", "root", "", "proud");

$errorMsg=$name2 = $Opassword = $Npassword = "";
$success=0;


if (isset($_POST['Opassword'])){
	$Opassword = preg_replace("[^A-Za-z0-9]", "", $_POST['Opassword']);
	$Npassword = preg_replace("[^A-Za-z0-9]", "", $_POST['Npassword']);

	if(!$Opassword){
		$errorMsg = "You must submit <b><i>Old Password</i></b> to continue";
		if(!$Npassword){
			
	       $errorMsg = "You must submit <b><i>New Password</i></b> to continue"; 
	   }
	}
	else {
		
		
		
		if($_SESSION['password']!=$Opassword){
			echo 'your pasword is wrong';
			$success=0;
		}
		else{
			// $hashedPass = md5($Npassword);
			
			$id=$_SESSION['id'];
			
			
			$sql = mysqli_query($link,"UPDATE signup SET password = '$Npassword' WHERE id = '$id';");
			$success=1;
			$_SESSION['password']=$Npassword;
			
			setcookie("password", $Npassword, time()+60*60*24);
			session_destroy(); 
			header("location:home.php");
			
		}

	}
	
}


?>

<!DOCTYPE html>
<html>

<head>

<link rel="stylesheet" type="text/css" href="sign_up_page.css">



</head>

<body>

<div class="logout">

<button class="but_logout"><a href="logout.php">LOGOUT</a></button>

</div>

<div  > 
    <form action="update_profile.php" method="post" enctype="multipart/form-data"> 
  <fieldset>


<legend class="login_up"><p><h1>Update Profile</h1></p></legend>
<?php
if(isset($_SESSION['username'])){
	echo $_SESSION['username'];
}
?>
<p1 style="color:red;"><?php echo "$errorMsg"; ?></p1>

<?php if($success==1){
	$name2=$_SESSION['fullname'];
	$errorMsg = $username = $email = $password = $mobile = $hscYear = $bd = $inst =  "";
	 echo '<p style="color: green; text-align: left">
	 <br>Hello!!</p>'." ".$name2." ".'<p style="color:blue; ">
	 <br> Your profile has been updated successfully !!
      </p>';
	
	$success=0;
	}
?>


<p> <label class="field" for="name"> Old Password       :</label><input type="password" placeholder="Letters, numbers and spaces"  name="Opassword" ? ></p>

<p> <label class="field" for="name"> New Password       :</label><input type="password" placeholder="Letters, numbers and spaces"  name="Npassword" ? ></p>

<p>please login after submission</p>







<input type="submit" class="button" name="submit" value="Submit Form">


 </fieldset>
</form></div> 

</body>

</html>